// stdafx.cpp : source file that includes just the standard includes
//	core12.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "StdAfx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
